# RTX 20-series / SM75 — experimental X5 and X6

Two binary patch prototypes based on the uploaded SM76 package and Coldwood1026's SM75 backend. They extend CPU-side multi-frame limits. **No Windows, RTX GPU, game, image quality, frame pacing, or performance validation has been performed.** They may fail to load or render correctly; successful CPU tests do not establish working frame generation.

| Folder | Generated frames per real frame | Total multiplier cap |
| --- | --- | --- |
| SM75-X5-experimental | 4 | X5 |
| SM75-X6-experimental | 5 | X6 |

Use one complete folder at a time. These are capability limits: the game/integration must request every generated frame and present them. An X4-only game will not acquire X5/X6 menu options or a new presentation implementation from this package. Actual FPS need not scale with the multiplier.

## Install for testing

1. Exit the game. Back up existing `version.dll`, `dinput8.dll`, `dlssg_sm86.ini`, and `runtime` outside its folder. Keep that backup for rollback; do not overwrite unrelated mods without resolving the conflict.
2. From ONE variant folder, copy `version.dll`, `dinput8.dll`, `dlssg_sm86.ini`, and the complete `runtime` folder beside the actual rendering EXE. The Witcher 3 DX12 location is `bin\x64_dx12`. Preserve these filenames. The dinput8 DLL here is the SM75 injector, not the alternative proxy from the supplied SM86 X6 archive.
3. Move any existing `%LOCALAPPDATA%\DlssgSm86\bundles` directory to a backup location before launching, so old cached bundles cannot be reused. Do not remove other application data.
4. Leave the game's separate original DLSSG DLL in place. The INI pins the included experimental runtime. Never mix a runtime, backend, or INI from different variants: both the backend and INI match the exact runtime SHA256.
5. Enable frame generation in the game. Select X5/X6 only if its integration supports that count. Start with X5. If no higher option exists, this package alone cannot force the game to present more frames.

For a lower-cap control, use a copy of either experimental folder and set `MaxGeneratedFrames=1` (X2) or `3` (X4), then restart. This remains the experimental runtime; restore the complete original package to compare against an unmodified baseline.

## Verify on hardware

Check `dlssg_sm86\logs` and `dlssg_sm75_inject.log` beside the EXE. The loader should report pinned mode, Cubin, the intended external SM75 backend, and `backend_install` status 0. Reject a run with a runtime hash mismatch, bridge error, kernel creation failure, crash, or device removal.

Inspect the backend's `mfg_capability` event: `reported_max` should be 4 or 5. Evaluation diagnostics should show `multi_frame_count` of 4 or 5 and the corresponding indices. Logging is intentionally verbose (`EvaluateEvery=1`); reduce it after diagnosis. Debug frame markers remain disabled and retain their original three-frame guard.

A reported maximum is not proof of frame generation. Confirm that the caller requests every index, then capture actual presentation/output to verify distinct intermediate frames, correct ordering, frame pacing, reset behavior, and image quality. Test camera cuts, menus, alt-tab, resolution changes, and FG toggling. Record GPU model, driver, game version, logs, and observed output. No throughput, latency, or VRAM claims are made here.

## Rollback

Exit the game, remove only files copied from the chosen variant, and restore your backed-up proxy DLLs, INI, runtime folder and cache as needed. Do not delete the game's own unrelated DLSS files.

## Implementation

The supplied X6 archive uses Native 0.2.4 with an integrated evaluation path. This SM75 package instead uses an older loader, a separate backend, and NVIDIA runtime 310.1. Its loader already accepts a setting up to 16, so its parser does not need the newer archive's parser patch.

Changes per variant:

- The external SM75 backend's configuration clamp changes from 3 to 4 or 5.
- The pinned runtime's capability maximum, evaluation count maximum, and error diagnostic change to match.
- Three runtime MFG architecture comparisons accept the existing Ada architecture report (0x190) instead of requiring 0x1B0. The SM75 injector/backend's existing architecture reporting and kernel routing remain intact. This altered runtime path itself needs hardware validation.
- The backend retains strict SHA256 matching, updated to the newly patched runtime; the INI uses that same hash.
- Patched files receive fresh PE checksums. The runtime's invalidated Authenticode certificate is removed; the modified runtime and backend are unsigned.

The loader and SM75 injector are byte-identical to the uploaded originals. The external backend's entire resource section, including all SM75 cubin/PTX assets, is unchanged. Runtime model/kernel data and resources are unchanged. Embedded legacy runtime/backend resources in `version.dll` remain unchanged and are not the selected route: retain `Mode=Pinned` and the complete external runtime folder.

The existing interpolation instruction block computes index/(count+1), yielding 1/5 through 4/5 and 1/6 through 5/6. CPU emulation confirms that arithmetic. It does not validate how every GPU/model path consumes those fractions, internal allocation sizes throughout the runtime, or the complete rendering/presentation pipeline.

See each variant's `patch-audit.json` for exact original/output hashes, RVAs and bytes; `SHA256SUMS.txt` covers its install files and audit. See `source/test-results.txt` for six passing host test methods, including boundary cases, original-build controls, exact change scope, unchanged resources, deterministic rebuilding, and refusal of already-patched inputs. Emulation stubs the architecture query; it does not execute Windows APIs or NVIDIA drivers.

## Reproduce

Python 3.10+, `pefile`, and (for tests) `unicorn` are required. The native C++ sources are not included in the supplied packages/repository; the included Python source reproduces the binary edits, not a C++ rebuild.

Obtain the original SM75 package from https://github.com/Coldwood1026/dlssg_for_sm75 including both files under `runtime`. The supplied SM76.rar alone omits that directory. The builder verifies every DLL against pinned source hashes before writing a new output directory.

```sh
python -m pip install pefile unicorn
python source/build_sm75.py --source ORIGINAL_SM75_FOLDER --output NEW_X5_FOLDER --multiplier 5
python source/build_sm75.py --source ORIGINAL_SM75_FOLDER --output NEW_X6_FOLDER --multiplier 6
```

To rerun tests, set environment variable `SM75_BASELINE` to the original complete folder and `SM75_OUTPUT` to this archive's extracted top-level directory (containing both variant folders), then run `python source/test_sm75.py`.

## Sources and attribution

- SM75 baseline and missing runtime files: https://github.com/Coldwood1026/dlssg_for_sm75
- Upstream loader/backend: https://github.com/sdli1995/dlssg_for_sm86
- Conceptual reference: user-supplied `DLSSG-X6-experimental (3).zip`, especially `X5-X6-source.patch` and `docs/EXPERIMENTAL_MFG.md`.
- NVIDIA owns the proprietary runtime and associated assets; original third-party rights remain with their owners. This work does not supply a license to redistribute them or claim upstream endorsement. Use as a local experiment.
