"""Build hash-pinned, unverified SM75 X5/X6 experiments. Python 3.10+, pefile."""
import argparse, hashlib, json, shutil, struct
from pathlib import Path
import pefile
HASHES = {
 'version.dll':'2d7dc46e3b81bb29cb698a2b2ea3a4ef2dd3bcb5c90e86a47e035df4e1edaa37',
 'dinput8.dll':'948cadaeafc24a0cda1ab541bbc06a4a20da28a4835646cea9f5701f4892a210',
 'runtime/sm75_backend.dll':'d96fd76499e2ebe2926e7ea8266375e528f1f746d7f4d2b97aaa01d0c1996038',
 'runtime/nvngx_dlssg.dll':'c989c0ebd9cd21dbf3db0becd857aa1f218068d94da371d924331a6f0fb97525',
}
def sha(d): return hashlib.sha256(d).hexdigest()
def patch(data, edits):
 pe=pefile.PE(data=data); out=bytearray(data); audit=[]
 for rva,old,new,reason in edits:
  offset=pe.get_offset_from_rva(rva)
  if out[offset:offset+len(old)]!=old or len(old)!=len(new): raise ValueError(f'Anchor mismatch at {rva:x}')
  out[offset:offset+len(old)]=new
  audit.append(dict(rva=hex(rva),offset=offset,before=old.hex(),after=new.hex(),reason=reason))
 cert=pe.OPTIONAL_HEADER.DATA_DIRECTORY[4]; removed=0
 if cert.Size:
  if cert.VirtualAddress+cert.Size!=len(out): raise ValueError('Unexpected certificate layout')
  removed=cert.Size;out=out[:cert.VirtualAddress]
  struct.pack_into('<II',out,cert.get_file_offset(),0,0)
 q=pefile.PE(data=out);struct.pack_into('<I',out,q.OPTIONAL_HEADER.get_field_absolute_offset('CheckSum'),q.generate_checksum())
 q=pefile.PE(data=out)
 for s,t in zip(pe.sections,q.sections):
  if s.Name not in (b'.text\0\0\0',b'.rdata\0\0') and s.get_data()!=t.get_data():raise ValueError('Unexpected section change')
 return bytes(out),dict(sourceSha256=sha(data),outputSha256=sha(out),patches=audit,removedCertificateBytes=removed,checksum=q.OPTIONAL_HEADER.CheckSum)
def build(src,dest,multiplier):
 if multiplier not in (5,6):raise ValueError('Choose 5 or 6')
 if dest.exists():raise ValueError('Output already exists')
 inputs={p:(src/p).read_bytes() for p in HASHES}
 for p,h in HASHES.items():
  if sha(inputs[p])!=h:raise ValueError(f'Unknown input: {p}')
 cap=multiplier-1;c=bytes([cap]);a=bytes.fromhex
 runtime,ra=patch(inputs['runtime/nvngx_dlssg.dll'],[
  (0x26667,a('41b803000000'),a('41b8')+c+a('000000'),'Runtime capability generated-frame maximum'),
  (0x2666d,a('81ffb0010000'),a('81ff90010000'),'MFG capability threshold accepts existing Ada report'),
  (0x2668e,a('81ffb0010000'),a('81ff90010000'),'Associated capability flag uses same architecture threshold'),
  (0x3eac2,a('3db0010000'),a('3d90010000'),'Count validation uses MFG path for existing Ada report'),
  (0x3eac9,a('83fb03'),a('83fb')+c,'Runtime generated-frame count bound'),
  (0x3eace,a('c744242803000000'),a('c7442428')+c+a('000000'),'Error diagnostic reports matching bound'),
 ])
 runtime_hash=sha(runtime)
 backend,ba=patch(inputs['runtime/sm75_backend.dll'],[
  (0x15401,a('83792803'),a('837928')+c,'Backend configuration clamp comparison'),
  (0x1543a,a('c705dc4d040003000000'),a('c705dc4d0400')+c+a('000000'),'Backend configuration clamp result'),
  (0x42f00,HASHES['runtime/nvngx_dlssg.dll'].encode(),runtime_hash.encode(),'Retain strict runtime hash verification for this exact patched image'),
 ])
 dest.mkdir(parents=True);(dest/'runtime').mkdir()
 for p in ['version.dll','dinput8.dll']:(dest/p).write_bytes(inputs[p])
 (dest/'runtime/nvngx_dlssg.dll').write_bytes(runtime)
 (dest/'runtime/sm75_backend.dll').write_bytes(backend)
 ini=f''' ; SM75 / RTX 20-series X{multiplier} EXPERIMENTAL. GPU and game unverified.
; Cap only: caller must request and present {cap} generated frames.
[General]
Enabled=1
[FrameGeneration]
MaxGeneratedFrames={cap}
[Logging]
Level=3
File=1
DebugOutput=0
EvaluateEvery=1
Directory=dlssg_sm86\\logs
[Debug]
MarkGeneratedFrames=0
[Compatibility]
KernelImage=Cubin
ForceSM86Route=1
SimulateAmpere=1
[Runtime]
Mode=Pinned
Path=runtime\\nvngx_dlssg.dll
[Backends]
{runtime_hash}=runtime\\sm75_backend.dll
'''.lstrip()
 (dest/'dlssg_sm86.ini').write_text(ini)
 audit=dict(multiplierCap=multiplier,gpuValidated=False,gameValidated=False,sourceRepository='https://github.com/Coldwood1026/dlssg_for_sm75',inputs=HASHES,runtime=ra,backend=ba,unchanged=['version.dll','dinput8.dll','SM75 cubin and PTX resources'])
 (dest/'patch-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
 (dest/'SHA256SUMS.txt').write_text(''.join(sha(p.read_bytes())+'  '+p.relative_to(dest).as_posix()+'\n' for p in sorted(dest.rglob('*')) if p.is_file()))
 return audit
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--multiplier',type=int,choices=[5,6],required=True);args=p.parse_args();build(args.source,args.output,args.multiplier)
