import unittest,struct,json,tempfile,os
from pathlib import Path
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_64,UC_HOOK_CODE
from unicorn.x86_const import *
from build_sm75 import build,sha
BASE=0x180000000;DATA=0x1000000;STACK=0x2000000
ROOT=Path(__file__).resolve().parents[1]
SRC=Path(os.environ.get('SM75_BASELINE',str(ROOT/'inspect/sm75/SM76')));OUT=Path(os.environ.get('SM75_OUTPUT',str(ROOT/'deliverable')))
class Machine:
 def __init__(self,path):
  self.pe=pefile.PE(str(path));self.u=Uc(UC_ARCH_X86,UC_MODE_64)
  self.u.mem_map(BASE,(self.pe.OPTIONAL_HEADER.SizeOfImage+4095)&~4095)
  self.u.mem_write(BASE,self.pe.get_memory_mapped_image());self.u.mem_map(DATA,0x10000);self.u.mem_map(STACK,0x10000)
  self.u.reg_write(UC_X86_REG_RSP,STACK+0x8000)
 def w(self,address,value):self.u.mem_write(address,struct.pack('<I',value))
 def run(self,start,stops,arch=None):
  def hook(u,address,size,unused):
   if address-BASE in stops:u.emu_stop()
   if address==BASE+0x3eabc:
    u.reg_write(UC_X86_REG_EAX,arch);u.reg_write(UC_X86_REG_RIP,BASE+0x3eac2)
  h=self.u.hook_add(UC_HOOK_CODE,hook)
  self.u.emu_start(BASE+start,0,count=200)
  self.u.hook_del(h)
  return self.u.reg_read(UC_X86_REG_RIP)-BASE
class Tests(unittest.TestCase):
 def variants(self):
  yield SRC,3,False
  for m in (5,6):yield OUT/f'SM75-X{m}-experimental',m-1,True
 def test_backend_actual_clamp(self):
  for folder,cap,_ in self.variants():
   vm=Machine(folder/'runtime/sm75_backend.dll');vm.u.reg_write(UC_X86_REG_RCX,DATA)
   for n in [0,1,2,3,4,5,6,16,0xffffffff]:
    vm.w(DATA+0x28,n);vm.run(0x15401,{0x15444})
    got=struct.unpack('<I',vm.u.mem_read(BASE+0x5a220,4))[0]
    self.assertEqual(got,min(n,cap))
 def test_runtime_actual_count_and_index(self):
  for folder,cap,patched in self.variants():
   vm=Machine(folder/'runtime/nvngx_dlssg.dll')
   vm.u.reg_write(UC_X86_REG_RBP,DATA);vm.u.reg_write(UC_X86_REG_RSI,DATA+0x1000)
   vm.u.mem_write(DATA+0x1020,struct.pack('<Q',DATA+0x2000));vm.u.mem_write(DATA+0x2000,struct.pack('<Q',DATA+0x3000))
   for arch in [0x160,0x190,0x1b0]:
    for count in [0,1,2,3,4,5,6,0xffffffff]:
     for index in [0,1,2,3,4,5,6,0xffffffff]:
      vm.w(DATA+0x3dc,index);vm.w(DATA+0x3e0,count)
      stop=vm.run(0x3ea7c,{0x3ea8d,0x3eace,0x3eaf0,0x3eb1e,0x3ed91,0x3eb68},arch)
      limit=cap if arch >= (0x190 if patched else 0x1b0) else 1
      self.assertEqual(stop==0x3eb68,1<=count<=limit and 1<=index<=count,(folder,arch,count,index,hex(stop)))
 def test_runtime_capability(self):
  for folder,cap,patched in self.variants():
   vm=Machine(folder/'runtime/nvngx_dlssg.dll')
   for arch in [0x160,0x190,0x1b0]:
    vm.u.reg_write(UC_X86_REG_EDI,arch);vm.u.reg_write(UC_X86_REG_EBX,1)
    vm.run(0x26667,{0x26677})
    self.assertEqual(vm.u.reg_read(UC_X86_REG_R8D),cap if arch >= (0x190 if patched else 0x1b0) else 1)
 def test_interpolation_instruction_block(self):
  for folder,cap,_ in self.variants():
   vm=Machine(folder/'runtime/nvngx_dlssg.dll')
   vm.u.reg_write(UC_X86_REG_R15,DATA);vm.u.reg_write(UC_X86_REG_RDI,DATA+0x1000);vm.u.reg_write(UC_X86_REG_RSI,DATA+0x2000)
   for count in range(1,cap+1):
    for index in range(1,count+1):
     vm.w(DATA,index);vm.w(DATA+0x14b0,count);vm.run(0x4a349,{0x4a36f})
     got=vm.u.reg_read(UC_X86_REG_XMM2)&0xffffffff
     self.assertEqual(got,struct.unpack('<I',struct.pack('<f',index/(count+1)))[0])
 def test_change_scope_and_identity(self):
  for m in (5,6):
   folder=OUT/f'SM75-X{m}-experimental';audit=json.loads((folder/'patch-audit.json').read_text())
   for name,key in [('runtime/nvngx_dlssg.dll','runtime'),('runtime/sm75_backend.dll','backend')]:
    old=(SRC/name).read_bytes();new=(folder/name).read_bytes();pe=pefile.PE(data=old);q=pefile.PE(data=new)
    allowed=set()
    for p in audit[key]['patches']:allowed.update(range(p['offset'],p['offset']+len(bytes.fromhex(p['before']))))
    for off,length in [(pe.OPTIONAL_HEADER.get_field_absolute_offset('CheckSum'),4),(pe.OPTIONAL_HEADER.DATA_DIRECTORY[4].get_file_offset(),8)]:allowed.update(range(off,off+length))
    self.assertTrue(all(i in allowed for i,(a,b) in enumerate(zip(old,new)) if a!=b))
    self.assertEqual(q.generate_checksum(),q.OPTIONAL_HEADER.CheckSum)
    self.assertEqual(q.OPTIONAL_HEADER.DATA_DIRECTORY[4].Size,0)
    self.assertEqual(sha(new),audit[key]['outputSha256'])
    for s,t in zip(pe.sections,q.sections):
     if s.Name==b'.rsrc\0\0\0':self.assertEqual(s.get_data(),t.get_data())
   rh=sha((folder/'runtime/nvngx_dlssg.dll').read_bytes())
   self.assertIn(rh,(folder/'dlssg_sm86.ini').read_text());self.assertIn(rh.encode(),(folder/'runtime/sm75_backend.dll').read_bytes())
   for name in ['version.dll','dinput8.dll']:self.assertEqual((SRC/name).read_bytes(),(folder/name).read_bytes())
 def test_reproducibility_and_refusal(self):
  with tempfile.TemporaryDirectory() as t:
   for m in (5,6):
    target=Path(t)/str(m);build(SRC,target,m)
    for p in target.rglob('*'):
     if p.is_file():self.assertEqual(p.read_bytes(),(OUT/f'SM75-X{m}-experimental'/p.relative_to(target)).read_bytes())
    with self.assertRaises(ValueError):build(SRC,target,m)
   with self.assertRaises(ValueError):build(OUT/'SM75-X6-experimental',Path(t)/'repatch',6)
if __name__=='__main__':unittest.main(verbosity=2)
